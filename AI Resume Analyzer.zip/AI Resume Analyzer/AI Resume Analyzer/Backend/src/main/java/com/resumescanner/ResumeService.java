package com.resumescanner;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ResumeService {

    @Value("${app.upload.dir}")
    private String uploadDir;

    public ResumeService() {
    }

    public ResumeAnalysis analyzeResume(
            String filename,
            String jobTitle,
            String jobDescription) throws IOException {

        ResumeAnalysis analysis = new ResumeAnalysis();

        analysis.setResumeFile(filename);

        String resumeText = extractTextFromPDF(filename);
        analysis.setResumeText(resumeText);

        analysis.setCandidateName(extractCandidateName(resumeText));
        analysis.setExperience(extractExperience(resumeText));
        analysis.setSkills(extractSkills(resumeText));

        List<String> matchedSkills =
                extractMatchedSkills(analysis.getSkills(), jobDescription);

        analysis.setMatchedSkills(matchedSkills);

        analysis.setAiFeedback(
                getAIFeedback(resumeText, jobTitle, jobDescription));

        analysis.setMatchScore(
                calculateMatchScore(
                        analysis.getSkills(),
                        matchedSkills));

        return analysis;
    }

    private String extractTextFromPDF(String filename) throws IOException {

        Path filePath = Paths.get(uploadDir, filename);

        try (PDDocument document =
                     Loader.loadPDF(filePath.toFile())) {

            PDFTextStripper stripper =
                    new PDFTextStripper();

            return stripper.getText(document);
        }
    }

    private String extractCandidateName(String text) {

        String[] lines = text.split("\\r?\\n");

        for (String line : lines) {

            String cleaned = line.trim();

            if (cleaned.matches("^[A-Za-z\\s]{3,50}$")) {
                return cleaned;
            }
        }

        return lines.length > 0
                ? lines[0].trim()
                : "Unknown";
    }

    private int extractExperience(String text) {

        Pattern pattern =
                Pattern.compile("(\\d+)\\s*years?");

        Matcher matcher =
                pattern.matcher(text.toLowerCase());

        if (matcher.find()) {
            return Integer.parseInt(matcher.group(1));
        }

        return 0;
    }

    private List<String> extractSkills(String text) {

        List<String> commonSkills = List.of(
                "Java",
                "Python",
                "JavaScript",
                "Spring",
                "React",
                "Angular",
                "SQL",
                "MySQL",
                "PostgreSQL",
                "MongoDB",
                "Docker",
                "Kubernetes",
                "AWS",
                "Azure",
                "Git",
                "Agile",
                "Microservices",
                "REST",
                "API"
        );

        List<String> foundSkills =
                new ArrayList<>();

        for (String skill : commonSkills) {

            if (text.toLowerCase()
                    .contains(skill.toLowerCase())) {

                foundSkills.add(skill);
            }
        }

        return foundSkills;
    }

    private List<String> extractMatchedSkills(
            List<String> skills,
            String jobDescription) {

        List<String> matched =
                new ArrayList<>();

        for (String skill : skills) {

            if (jobDescription.toLowerCase()
                    .contains(skill.toLowerCase())) {

                matched.add(skill);
            }
        }

        return matched;
    }

    private String getAIFeedback(
            String resumeText,
            String jobTitle,
            String jobDescription) {

        return "Resume analyzed successfully.";
    }

    private double calculateMatchScore(
            List<String> skills,
            List<String> matchedSkills) {

        if (skills == null || skills.isEmpty()) {
            return 0.0;
        }

        return Math.round(
                ((double) matchedSkills.size()
                        / skills.size()) * 100.0);
    }
}