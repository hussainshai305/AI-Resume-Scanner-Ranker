package com.resumescanner;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Paths;

@Component
public class DataInitializer {

    @PostConstruct
    public void init() {
        try {
            Files.createDirectories(Paths.get("uploads"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
