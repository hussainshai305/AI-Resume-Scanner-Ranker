package com.resumescanner;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class ResumeController {

    private final ResumeService resumeService;

    private final String uploadDir = "uploads";

    public ResumeController(ResumeService resumeService) {
        this.resumeService = resumeService;
    }

    @PostMapping("/upload/resume")
    public ResponseEntity<Map<String, Object>> uploadResume(
            @RequestParam("resume") MultipartFile file
    ) {

        Map<String, Object> response = new HashMap<>();

        try {

            Files.createDirectories(Paths.get(uploadDir));

            String originalFilename =
                    Objects.requireNonNull(file.getOriginalFilename());

            Path filePath =
                    Paths.get(uploadDir, originalFilename);

            Files.copy(
                    file.getInputStream(),
                    filePath,
                    StandardCopyOption.REPLACE_EXISTING
            );

            response.put("status", "success");
            response.put("filename", originalFilename);
            response.put("message", "File uploaded successfully");

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            response.put("status", "error");
            response.put("message", "Upload failed");
            response.put("error", e.getMessage());

            return ResponseEntity.status(500).body(response);
        }
    }

    @PostMapping("/analyze")
    public ResponseEntity<List<ResumeAnalysis>> analyzeResumes(
            @RequestBody Map<String, Object> request
    ) {

        try {

            List<String> resumeFiles =
                    (List<String>) request.get("resumeFiles");

            String jobTitle =
                    (String) request.get("jobTitle");

            String jobDescription =
                    (String) request.get("jobDescription");

            List<ResumeAnalysis> results =
                    new ArrayList<>();

            for (String filename : resumeFiles) {

                results.add(
                        resumeService.analyzeResume(
                                filename,
                                jobTitle,
                                jobDescription
                        )
                );
            }

            results.sort(
                    (a, b) ->
                            Double.compare(
                                    b.getMatchScore(),
                                    a.getMatchScore()
                            )
            );

            return ResponseEntity.ok(results);

        } catch (Exception e) {

            return ResponseEntity.status(500).build();
        }
    }

    @GetMapping("/resume/{filename}")
    public ResponseEntity<byte[]> getResume(
            @PathVariable String filename
    ) {

        try {

            Path filePath =
                    Paths.get(uploadDir, filename);

            byte[] fileData =
                    Files.readAllBytes(filePath);

            return ResponseEntity.ok()
                    .header(
                            HttpHeaders.CONTENT_DISPOSITION,
                            "inline; filename=\"" + filename + "\""
                    )
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(fileData);

        } catch (IOException e) {

            return ResponseEntity.notFound().build();
        }
    }
}