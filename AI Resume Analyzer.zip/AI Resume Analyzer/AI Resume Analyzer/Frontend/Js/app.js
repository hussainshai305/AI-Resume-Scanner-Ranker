// API Configuration
const API_BASE_URL = 'http://localhost:8081/api';

// State
let uploadedFiles = [];
let analysisResults = [];

// ===== DOM Elements =====
const fileInput = document.getElementById('fileInput');
const uploadBox = document.getElementById('uploadBox');
const uploadProgress = document.getElementById('uploadProgress');
const uploadCount = document.getElementById('uploadCount');
const progressFill = document.getElementById('progressFill');
const uploadedFilesDiv = document.getElementById('uploadedFiles');
const jobTitle = document.getElementById('jobTitle');
const jobDescription = document.getElementById('jobDescription');
const threshold = document.getElementById('threshold');
const thresholdValue = document.getElementById('thresholdValue');
const analyzeBtn = document.getElementById('analyzeBtn');
const resultsSection = document.getElementById('resultsSection');
const resultsBody = document.getElementById('resultsBody');
const loadingSection = document.getElementById('loadingSection');

// ===== Event Listeners =====

// File input change
fileInput.addEventListener('change', handleFiles);

// Drag and drop
uploadBox.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadBox.classList.add('drag-over');
});

uploadBox.addEventListener('dragleave', () => {
    uploadBox.classList.remove('drag-over');
});

uploadBox.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadBox.classList.remove('drag-over');
    const files = e.dataTransfer.files;
    handleFileSelect(files);
});

// Threshold slider
threshold.addEventListener('input', (e) => {
    thresholdValue.textContent = e.target.value + '%';
});

// ===== File Upload Functions =====

function handleFiles(e) {
    handleFileSelect(e.target.files);
}

function handleFileSelect(files) {
    if (files.length === 0) return;
    
    uploadFiles(files);
}

async function uploadFiles(files) {
    // Show progress
    uploadProgress.style.display = 'block';
    uploadCount.textContent = files.length;
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const progress = ((i + 1) / files.length) * 100;
        progressFill.style.width = progress + '%';
        
        try {
            const result = await uploadFile(file);
            uploadedFiles.push({
                name: file.name,
                size: file.size,
                ...result
            });
            updateUploadedFilesList();
        } catch (error) {
            console.error('Upload error:', error);
            alert(error);
        }
    }
    
    // Hide progress after completion
    setTimeout(() => {
        uploadProgress.style.display = 'none';
        progressFill.style.width = '0%';
    }, 1000);
}

async function uploadFile(file) {
    const formData = new FormData();
    formData.append('resume', file);
    
    const response = await fetch(`${API_BASE_URL}/upload/resume`, {
        method: 'POST',
        body: formData
    });
    
    if (!response.ok) {
        throw new Error('Upload failed');
    }
    
    return await response.json();
}

function updateUploadedFilesList() {
    uploadedFilesDiv.innerHTML = uploadedFiles.map(file => `
        <div class="uploaded-file">
            <i class="fas fa-file-pdf"></i>
            <div class="uploaded-file-name">${file.name}</div>
            <div class="uploaded-file-status">
                <i class="fas fa-check"></i> Uploaded
            </div>
        </div>
    `).join('');
}

// ===== Analysis Functions =====

async function analyzeResumes() {
    if (uploadedFiles.length === 0) {
        alert('Please upload resumes first');
        return;
    }
    
    if (!jobTitle.value || !jobDescription.value) {
        alert('Please fill in job title and description');
        return;
    }
    
    // Show loading
    loadingSection.style.display = 'flex';
    resultsSection.style.display = 'none';
    analyzeBtn.disabled = true;
    
    try {
        const response = await fetch(`${API_BASE_URL}/analyze`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                resumeFiles: uploadedFiles.map(f => f.name),
                jobTitle: jobTitle.value,
                jobDescription: jobDescription.value,
                threshold: parseInt(threshold.value)
            })
        });
        
        if (!response.ok) {
            throw new Error('Analysis failed');
        }
        
        analysisResults = await response.json();
        displayResults();
        
    } catch (error) {
        console.error('Analysis error:', error);
        alert('Failed to analyze resumes. Please try again.');
    }
    
    // Hide loading
    loadingSection.style.display = 'none';
    analyzeBtn.disabled = false;
}

function displayResults() {
    // Update stats
    document.getElementById('totalResumes').textContent = analysisResults.length;
    document.getElementById('matchedResumes').textContent = 
        analysisResults.filter(r => r.matchScore >= parseInt(threshold.value)).length;
    document.getElementById('topScore').textContent = 
        Math.max(...analysisResults.map(r => r.matchScore)) + '%';
    
    // Display results
    resultsSection.style.display = 'block';
    resultsBody.innerHTML = analysisResults.map((result, index) => {
        const scoreClass = result.matchScore >= 80 ? 'high' : 
                          result.matchScore >= 60 ? 'medium' : 'low';
        
        const skillsHTML = result.skills.map(skill => {
            const isMatched = result.matchedSkills.includes(skill);
            return `<span class="skill-badge ${isMatched ? 'matched' : ''}">${skill}</span>`;
        }).join('');
        
        return `
            <tr>
                <td><div class="rank-badge">${index + 1}</div></td>
                <td>
                    <div class="candidate-info">
                        <div class="candidate-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="candidate-name">${result.candidateName || 'Unknown'}</div>
                    </div>
                </td>
                <td>${result.resumeFile}</td>
                <td>
                    <div class="match-score ${scoreClass}">
                        <i class="fas fa-star"></i>
                        ${result.matchScore}%
                    </div>
                </td>
                <td>${result.experience || '0'} years</td>
                <td>
                    <div class="skills-container">${skillsHTML}</div>
                </td>
                <td>
                    <div class="ai-feedback">${result.aiFeedback || 'No feedback available'}</div>
                </td>
                <td>
                    <div class="actions">
                        <button class="action-btn view" onclick="viewResume('${result.resumeFile}')">
                            <i class="fas fa-eye"></i> View
                        </button>
                        <button class="action-btn download" onclick="downloadResume('${result.resumeFile}')">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// ===== Action Functions =====

function viewResume(filename) {
    // Open resume in new window
    window.open(`${API_BASE_URL}/resume/${filename}`, '_blank');
}

function downloadResume(filename) {
    // Download resume
    const link = document.createElement('a');
    link.href = `${API_BASE_URL}/resume/${filename}`;
    link.download = filename;
    link.click();
}

// ===== Initialize =====
console.log('AI Resume Scanner & Ranker initialized');